import app from './es-ES/app';
import menu from './es-ES/menu';
import measures from './es-ES/measures';

export default {
  ...app,
  ...menu,
  ...measures,
};
