import app from './de-DE/app';
import menu from './de-DE/menu';
import measures from './de-DE/measures';

export default {
  ...app,
  ...menu,
  ...measures,
};
