import app from './el-GR/app';
import menu from './el-GR/menu';
import measures from './el-GR/measures';

export default {
  ...app,
  ...menu,
  ...measures,
};
