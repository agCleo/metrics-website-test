import app from './en-GB/app';
import menu from './en-GB/menu';
import measures from './en-GB/measures';

export default {
  ...app,
  ...menu,
  ...measures,
};
